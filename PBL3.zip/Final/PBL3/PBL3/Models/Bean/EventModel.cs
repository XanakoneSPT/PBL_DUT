﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PBL3.Model.Bean
{
    public class EventModel
    {
        public string EventId { get; set; }
        public string EvenName { get; set; }
        public string Time { get; set; }
        public string Location { get; set; }
    }
}
